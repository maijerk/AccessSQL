﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccesSQL
{
    public partial class SQLForm : Form
    {

        public OleDbConnection Connection;

        public SQLForm()
        {
            InitializeComponent();
        }

        public DataSet GetData()
        {
            DataSet ds = new DataSet();
            ds.Tables.Add("sql");
            String query = txtSQL.Text;

            OleDbDataAdapter adapter = new OleDbDataAdapter(query, Connection);
            try
            {
                adapter.Fill(ds, "sql");
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Fout", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return ds;
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            sqlDataGrid.DataSource = GetData();
            sqlDataGrid.DataMember = "sql";
            
        }
    }
}

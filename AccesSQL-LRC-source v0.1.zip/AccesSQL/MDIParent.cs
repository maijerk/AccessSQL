﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccesSQL
{
    public partial class MDIParent : Form
    {
        private int childFormNumber = 0;
        private int sqlFormNumber = 0;

        private string fileName;

        private OleDbConnection conn;

        public MDIParent()
        {
            InitializeComponent();
        }

        private void ShowNewForm(object sender, EventArgs e)
        {
            openDBFileDialog.InitialDirectory = Application.StartupPath;
            //openFileDialog.Filter = "Acces files (*.mdb)";
            if (openDBFileDialog.ShowDialog(this) == DialogResult.OK)
            {

                fileName = openDBFileDialog.FileName;
                conn = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source = " + fileName + "; Persist Security Info = False");
                conn.Open();
            }

            DBForm childForm = new DBForm();
            childForm.Connection = conn;
            childForm.MdiParent = this;
            childForm.Text = "Database " + ++childFormNumber;
            childForm.Show();
            openToolStripMenuItem.Enabled = false;
            
            sqlMenuItem.Enabled = true;
            databaseMenuItem.Enabled = true;
            closeToolStripMenuItem.Enabled = true;

            toolStripStatusLabel.Text = "Actieve database: " + fileName;

        }

        private void OpenFile(object sender, EventArgs e)
        {
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form child in MdiChildren)
            {
                child.Close();
            }
            conn.Close();
            openToolStripMenuItem.Enabled = true;

            sqlMenuItem.Enabled = false;
            databaseMenuItem.Enabled = false;

            childFormNumber = 0;
            sqlFormNumber = 0;
            toolStripStatusLabel.Text = "Status";

        }

        private void sQLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SQLForm childForm = new SQLForm();
            childForm.Connection = conn;
            childForm.MdiParent = this;
            childForm.Text = "SQL " + ++sqlFormNumber;
            childForm.Show();

        }

        private void databaseMenuItem_Click(object sender, EventArgs e)
        {
            DBForm childForm = new DBForm();
            childForm.Connection = conn;
            childForm.MdiParent = this;
            childForm.Text = "Database " + ++childFormNumber;
            childForm.Show();

        }

        private void MDIParent_Load(object sender, EventArgs e)
        {

        }
    }
}
